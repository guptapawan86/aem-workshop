/*
 * Interim demo-only shim: the core ContentAISupportedSearch component (as
 * currently released) inserts the AI-generated summary via textContent, so
 * Content AI's Markdown response (bold, links, bullet lists) shows up as
 * literal characters. The real fix lives in contentaisearch.js on the
 * docs/contentai-api-key-config branch of aem-core-wcm-components; this
 * shim reproduces the same rendering here, without modifying the shipped
 * component.
 *
 * It intercepts the assignment itself (via a property override on
 * .textContent), rather than reacting to it after the fact with a
 * MutationObserver. The component sets the raw text, populates the sources
 * list, and unhides the whole summary card all in one synchronous call
 * (_renderSummary) - a MutationObserver only finds out about that a
 * microtask later, after the raw, unstyled full answer has already
 * committed to the DOM once. Intercepting the setter means the raw text
 * never touches the DOM at all; we take the value directly and render our
 * own output in its place.
 *
 * It also fakes a word-by-word "streaming" reveal of that text. The real
 * Content AI API does have a genuine SSE streaming endpoint
 * (/content-sources/gensearch/stream), but wiring that through would mean
 * the AEM servlet relaying an SSE connection per configured content source
 * and merging partial chunks live - a real core-components change, not a
 * page-level shim. This is the cosmetic stand-in: the full answer is
 * already in hand (the existing blocking .gensearch.json call hasn't
 * changed), it's just revealed progressively instead of painted in one go,
 * so it doesn't reduce actual latency - the wait before the first word
 * appears is unchanged, only what happens after.
 */
(function() {
    "use strict";

    var SELECTOR = ".cmp-contentaisearch__summary-text";

    function escapeHtml(str) {
        return String(str)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#39;");
    }

    function stripAsciiControlsAndWhitespaceForSchemeCheck(str) {
        var out = "";
        var i;
        var ch;
        var c;
        for (i = 0; i < str.length; i++) {
            ch = str.charAt(i);
            c = str.charCodeAt(i);
            if (c <= 31 || c === 127 || /\s/.test(ch)) {
                continue;
            }
            out += ch;
        }
        return out;
    }

    function isSafeUrl(url) {
        if (!url) {
            return false;
        }
        return /^https?:\/\//i.test(stripAsciiControlsAndWhitespaceForSchemeCheck(String(url)));
    }

    function renderInline(text) {
        var html = escapeHtml(text);
        html = html.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
        html = html.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, function(match, label, url) {
            return isSafeUrl(url) ? '<a href="' + url + '">' + label + "</a>" : label;
        });
        return html;
    }

    function renderMarkdown(text) {
        var lines = String(text || "").split(/\r?\n/);
        var html = "";
        var listOpen = false;
        var i;
        var trimmed;
        for (i = 0; i < lines.length; i++) {
            trimmed = lines[i].replace(/^\s+/, "");
            if (/^[-*]\s+/.test(trimmed)) {
                if (!listOpen) {
                    html += "<ul>";
                    listOpen = true;
                }
                html += "<li>" + renderInline(trimmed.replace(/^[-*]\s+/, "")) + "</li>";
            } else {
                if (listOpen) {
                    html += "</ul>";
                    listOpen = false;
                }
                if (trimmed.length > 0) {
                    html += "<p>" + renderInline(trimmed) + "</p>";
                }
            }
        }
        if (listOpen) {
            html += "</ul>";
        }
        return html;
    }

    // The real generation call already takes several seconds on its own -
    // this reveal only runs after that response has already arrived, so it
    // must stay quick. A single fixed per-word interval, no duration-scaling
    // math - just reveal one more word every tick.
    var WORD_INTERVAL_MS = 12;

    // The sources list is populated and shown by the core component in the
    // very same synchronous call that sets the raw summary text - it doesn't
    // wait for anything. Hide it for the duration of our reveal and only
    // show it once the answer has fully finished typing out.
    function findSourcesList(node) {
        var summary = node.closest('[data-cmp-hook-contentaisearch="summary"]');
        return summary ? summary.querySelector('[data-cmp-hook-contentaisearch="sources"]') : null;
    }

    // The crawled WKND pages have no title in their metadata at all (only
    // a url), so the component's own fallback (_labelFromUrl) is what's
    // showing: the last URL segment with dashes swapped for spaces, but
    // still carrying the .html extension and no capitalization - e.g.
    // "ski touring mont blanc.html". Only clean up labels that actually
    // look like that fallback pattern (a dash/underscore slug, or a
    // trailing page extension) so a genuine metadata.title, if one ever
    // shows up, is left exactly as authored rather than forced through
    // title-casing.
    function beautifySourceLabel(text) {
        var label = String(text || "");
        var looksLikeUrlFallback = /[-_]/.test(label) || /\.(html?|php|aspx?)$/i.test(label);
        if (!looksLikeUrlFallback) {
            return label;
        }
        label = label.replace(/\.(html?|php|aspx?)$/i, "").replace(/[-_]+/g, " ").trim();
        return label.replace(/\S+/g, function(word) {
            return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
        });
    }

    function beautifySourceLabels(sources) {
        if (!sources) {
            return;
        }
        var nodes = sources.querySelectorAll(
            '[data-cmp-hook-contentaisearch="sourceLink"], [data-cmp-hook-contentaisearch="sourceText"]'
        );
        var i;
        for (i = 0; i < nodes.length; i++) {
            nodes[i].textContent = beautifySourceLabel(nodes[i].textContent);
        }
    }

    function revealWords(node, fullText) {
        // Keep whitespace (including newlines) as its own tokens so slicing
        // reconstructs the exact original spacing/line breaks at every step.
        var tokens = fullText.split(/(\s+)/);
        var idx = 0;
        var sources = findSourcesList(node);

        if (node.__gensearchRevealTimer) {
            clearTimeout(node.__gensearchRevealTimer);
        }
        node.innerHTML = "";
        if (sources) {
            sources.style.visibility = "hidden";
        }

        function tick() {
            idx++;
            // Render through the same p/ul/li markdown structure on every
            // tick, not just the last one, so paragraph/list spacing is
            // already in place from the first word instead of appearing all
            // at once at the end.
            node.innerHTML = renderMarkdown(tokens.slice(0, idx).join(""));
            if (idx < tokens.length) {
                node.__gensearchRevealTimer = setTimeout(tick, WORD_INTERVAL_MS);
            } else {
                node.__gensearchRevealTimer = null;
                if (sources) {
                    beautifySourceLabels(sources);
                    sources.style.visibility = "";
                }
            }
        }

        tick();
    }

    // Intercept the .textContent setter itself instead of reacting to it
    // after the fact - the raw answer never touches the DOM, not even for a
    // moment, so there's nothing for a MutationObserver-based approach to
    // race against.
    function interceptNode(node) {
        var nativeDescriptor = Object.getOwnPropertyDescriptor(Node.prototype, "textContent");
        Object.defineProperty(node, "textContent", {
            configurable: true,
            get: function() {
                return nativeDescriptor.get.call(node);
            },
            set: function(value) {
                revealWords(node, String(value || ""));
            }
        });
    }

    function init() {
        var nodes = document.querySelectorAll(SELECTOR);
        var i;
        for (i = 0; i < nodes.length; i++) {
            interceptNode(nodes[i]);
        }
    }

    if (document.readyState !== "loading") {
        init();
    } else {
        document.addEventListener("DOMContentLoaded", init);
    }
})();
