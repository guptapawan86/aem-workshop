/*
 * Interim demo-only shim for two bugs in the core ContentAISupportedSearch
 * component (as currently released). The real fixes live in
 * contentaisearch.js on the docs/contentai-api-key-config branch of
 * aem-core-wcm-components; deploying those requires rebuilding and
 * reinstalling the whole core-components bundle, out of scope for this
 * page-level package - so in the meantime both are reproduced here via
 * fetch interception, since the component's own constructor is private to
 * its IIFE and can't be monkey-patched directly.
 *
 * 1. Stale-response race: _runResultsSearch/_runGenSearch/_runLoadMore each
 *    fire a fetch for the query typed at that moment, but never re-check
 *    whether that query is still current by the time the response arrives.
 *    Typing quickly can let a slower, now-stale response (e.g. a
 *    low-confidence "I don't have enough information" answer for a short
 *    partial query) render after a newer response already has, causing a
 *    visible flicker / wrong-answer flash. This shim tracks the latest
 *    request per (resourcePath, endpoint) and, if a response arrives after
 *    a newer request for the same pair was already issued, returns a
 *    promise that never resolves - the component never gets a callback for
 *    it, so it can't render the stale data.
 *
 * 2. Result cards/list items and source chips never linked to their source
 *    page, because the component only ever reads metadata.url - but
 *    Content AI's own acquisition indexing convention stores the crawled
 *    page address as metadata.source (duplicated at data.source), not
 *    metadata.url. This shim augments metadata.url = metadata.source on
 *    every item/hit that's missing it, before the response reaches the
 *    component, so its existing (correct) href-setting logic just works.
 *
 * 3. Clicking the clear (x) button empties the input and clears results
 *    client-side, but a request already in flight when clear is clicked
 *    (e.g. typed a query, then hit clear before it resolved) can still
 *    resolve afterwards and silently repopulate results/summary, since
 *    nothing invalidates it. This shim binds its own click listener on
 *    every clear button: it bumps the same latest-request tracking used
 *    for bug 1 (so any in-flight response for that component instance is
 *    now treated as stale and never rendered) and, as a belt-and-suspenders
 *    safety net, force-clears the results/summary DOM directly.
 *
 * 4. Type-ahead fires a request on every ~300ms pause while typing (the
 *    component only ever binds its search to the input's own "input" event -
 *    there's no separate submit-triggered search to fall back to). That's
 *    the actual source of the flicker: every brief typing pause sends a
 *    fresh, often-incomplete query and re-renders whatever comes back. This
 *    shim gates every non-load-more request behind an explicit trigger
 *    instead of letting type-ahead through at all: a fresh request for a
 *    (resourcePath, endpoint) is only dispatched once the user has pressed
 *    Enter in that field (any other keystroke re-disarms it, so a further
 *    edit needs another Enter) or changed the AI-answer toggle (a deliberate
 *    action of its own, always allowed through immediately). Everything else
 *    typed in between is silently dropped before it ever reaches the
 *    network. Load-more requests (cursors present) are unaffected - they're
 *    a single click, not a stream of keystrokes.
 *
 * 5. _setFieldLoading/_setSummaryLoading show their loading indicators
 *    synchronously the instant the component's own 300ms debounce fires,
 *    BEFORE it ever calls fetch - so even a type-ahead request that bug 4
 *    silently drops still visibly flashes the "generating an answer" loading
 *    state on every typing pause, giving the impression a search is running
 *    when nothing was actually sent. A CSS class on the component root
 *    (gensearch-loading-suppressed, added by default) force-hides those
 *    indicators regardless of what inline styles the component sets; this
 *    shim only removes that class for the span between a request actually
 *    being dispatched (the armed branch above) and its real response
 *    settling, so the loading state is visible only while a search is
 *    genuinely in flight.
 */
(function() {
    "use strict";

    var ENDPOINTS = [".search.json", ".gensearch.json"];
    var latestRequestId = {};
    var counter = 0;
    var originalFetch = window.fetch;

    function matchEndpoint(url) {
        var i;
        for (i = 0; i < ENDPOINTS.length; i++) {
            if (url.indexOf(ENDPOINTS[i]) !== -1) {
                return ENDPOINTS[i];
            }
        }
        return null;
    }

    function requestKey(endpoint, url) {
        var idx = url.indexOf(endpoint);
        return url.substring(0, idx) + endpoint;
    }

    function neverResolves() {
        return new Promise(function() {
            // Intentionally never settles - the caller's then()/catch() for
            // this stale response simply never fires.
        });
    }

    function fillMissingUrl(metadata, fallbackSource) {
        if (metadata && !metadata.url && (metadata.source || fallbackSource)) {
            metadata.url = metadata.source || fallbackSource;
        }
    }

    // WKND's crawled pages don't expose an og:image or any other standard
    // image meta tag, so Content AI's crawler never captures one - there's
    // nothing to fall back to in the indexed data itself. Using the WKND
    // logo here as a deliberate, on-brand placeholder rather than leaving
    // cards imageless, matching how card/list already handle a missing
    // image structurally (a plain <img> element expecting a src).
    var DEFAULT_IMAGE = "https://wknd.site/content/dam/wknd/en/site/wknd-logo-dk.svg";

    function fillMissingImage(metadata) {
        if (metadata && !metadata.image) {
            metadata.image = DEFAULT_IMAGE;
        }
    }

    function augmentMetadataUrls(data) {
        if (!data) {
            return data;
        }
        if (Array.isArray(data.results)) {
            data.results.forEach(function(item) {
                var itemData = item && item.data;
                if (itemData) {
                    fillMissingUrl(itemData.metadata, itemData.source);
                    fillMissingImage(itemData.metadata);
                }
            });
        }
        if (Array.isArray(data.hits)) {
            data.hits.forEach(function(hit) {
                fillMissingUrl(hit && hit.metadata, hit && hit.source);
            });
        }
        return data;
    }

    var armed = {};
    var armTimers = {};

    // Arming allows exactly one burst of requests through (the component
    // fires both .search.json and .gensearch.json from the same trigger, a
    // beat apart, so it can't be consumed by the very first one). It expires
    // on its own shortly after, well past the component's own 300ms debounce
    // plus enough margin for both requests to have been dispatched - so a
    // stray/duplicate retrigger later can't sneak a second real search
    // through and restart the whole reveal, which looks like a loop.
    var ARM_WINDOW_MS = 1000;

    function armResourcePath(resourcePath) {
        armed[resourcePath] = true;
        if (armTimers[resourcePath]) {
            clearTimeout(armTimers[resourcePath]);
        }
        armTimers[resourcePath] = setTimeout(function() {
            armed[resourcePath] = false;
            delete armTimers[resourcePath];
        }, ARM_WINDOW_MS);
    }

    function disarmResourcePath(resourcePath) {
        armed[resourcePath] = false;
        if (armTimers[resourcePath]) {
            clearTimeout(armTimers[resourcePath]);
            delete armTimers[resourcePath];
        }
    }

    var SUPPRESS_LOADING_CLASS = "gensearch-loading-suppressed";
    var resourcePathToRoot = {};
    var inFlightCount = {};

    function markSearching(resourcePath) {
        inFlightCount[resourcePath] = (inFlightCount[resourcePath] || 0) + 1;
        var root = resourcePathToRoot[resourcePath];
        if (root) {
            root.classList.remove(SUPPRESS_LOADING_CLASS);
        }
    }

    function markSettled(resourcePath) {
        inFlightCount[resourcePath] = Math.max(0, (inFlightCount[resourcePath] || 0) - 1);
        if (inFlightCount[resourcePath] === 0) {
            var root = resourcePathToRoot[resourcePath];
            if (root) {
                root.classList.add(SUPPRESS_LOADING_CLASS);
            }
        }
    }

    function processResponse(response, key, myId) {
        if (latestRequestId[key] !== myId) {
            return neverResolves();
        }
        if (!response.ok) {
            return Promise.resolve(response);
        }
        return response.json().then(function(data) {
            if (latestRequestId[key] !== myId) {
                return neverResolves();
            }
            augmentMetadataUrls(data);
            return {
                ok: true,
                status: response.status,
                statusText: response.statusText,
                json: function() {
                    return Promise.resolve(data);
                },
                clone: function() {
                    return this;
                }
            };
        });
    }

    window.fetch = function(input, init) {
        var url = typeof input === "string" ? input : (input && input.url) || "";
        var endpoint = matchEndpoint(url);

        if (!endpoint) {
            return originalFetch.apply(window, arguments);
        }

        var key = requestKey(endpoint, url);
        var myId = ++counter;
        latestRequestId[key] = myId;
        var fetchArgs = arguments;
        var isLoadMore = url.indexOf("cursors=") !== -1;

        if (isLoadMore) {
            return originalFetch.apply(window, fetchArgs).then(function(response) {
                return processResponse(response, key, myId);
            });
        }

        var resourcePath = url.substring(0, url.indexOf(endpoint));
        if (!armed[resourcePath]) {
            // Not an explicit Enter/toggle trigger - this is type-ahead noise
            // from a typing pause. Drop it before it ever reaches the
            // network; the component never gets a callback for it.
            return neverResolves();
        }

        markSearching(resourcePath);
        var realFetch = originalFetch.apply(window, fetchArgs);
        realFetch.then(
            function() {
                markSettled(resourcePath);
            },
            function() {
                markSettled(resourcePath);
            }
        );

        return realFetch.then(function(response) {
            return processResponse(response, key, myId);
        });
    };

    function invalidateResourcePath(resourcePath) {
        ENDPOINTS.forEach(function(endpoint) {
            latestRequestId[resourcePath + endpoint] = ++counter;
        });
    }

    function hide(el) {
        if (el) {
            el.style.display = "none";
            el.setAttribute("hidden", "hidden");
        }
    }

    var suppressResultsFade = false;

    function forceClear(root) {
        var hook = function(name) {
            return root.querySelector('[data-cmp-hook-contentaisearch="' + name + '"]');
        };
        var results = hook("results");
        if (results) {
            suppressResultsFade = true;
            results.innerHTML = "";
        }
        hide(hook("resultsSection"));
        hide(hook("loadMore"));
        hide(hook("summary"));
        hide(hook("summaryLoading"));
        hide(hook("error"));
    }

    function bindClearButtons() {
        var roots = document.querySelectorAll("[data-cmp-is=\"contentaisearch\"]");
        var i;
        for (i = 0; i < roots.length; i++) {
            (function(root) {
                var resourcePath = root.getAttribute("data-cmp-resource-path");
                var clearButton = root.querySelector('[data-cmp-hook-contentaisearch="clear"]');
                if (!clearButton || !resourcePath) {
                    return;
                }
                clearButton.addEventListener("click", function() {
                    invalidateResourcePath(resourcePath);
                    forceClear(root);
                });
            })(roots[i]);
        }
    }

    // Results replace their entire contents in one synchronous DOM write, so
    // there's no display:none/block toggle for a CSS animation to key off of
    // like the summary card has. Re-trigger the same fade-in keyframe on
    // every childList mutation instead, by removing and re-adding a class
    // (forcing a reflow in between so the browser treats it as a new
    // animation rather than a no-op).
    function bindResultsFade() {
        var containers = document.querySelectorAll('[data-cmp-hook-contentaisearch="results"]');
        var i;
        for (i = 0; i < containers.length; i++) {
            (function(el) {
                var observer = new MutationObserver(function() {
                    if (suppressResultsFade) {
                        suppressResultsFade = false;
                        return;
                    }
                    el.classList.remove("gensearch-refresh");
                    void el.offsetWidth;
                    el.classList.add("gensearch-refresh");
                });
                observer.observe(el, { childList: true });
            })(containers[i]);
        }
    }

    // Arms a resourcePath's next request on an explicit Enter press (forcing
    // the component's own debounced search to actually fire by dispatching a
    // synthetic "input" event, since the component never reacts to Enter
    // itself) or on the AI-answer toggle changing (a deliberate action with
    // its own immediate, non-debounced request). Any other keydown re-disarms
    // it, so an edit after a search always needs a fresh Enter.
    function bindSearchTrigger() {
        var roots = document.querySelectorAll("[data-cmp-is=\"contentaisearch\"]");
        var i;
        for (i = 0; i < roots.length; i++) {
            (function(root) {
                var resourcePath = root.getAttribute("data-cmp-resource-path");
                if (!resourcePath) {
                    return;
                }
                resourcePathToRoot[resourcePath] = root;
                root.classList.add(SUPPRESS_LOADING_CLASS);
                var input = root.querySelector('[data-cmp-hook-contentaisearch="input"]');
                if (input) {
                    input.addEventListener("keydown", function(event) {
                        if (event.key === "Enter" || event.keyCode === 13) {
                            event.preventDefault();
                            armResourcePath(resourcePath);
                            input.dispatchEvent(new Event("input", { bubbles: true }));
                        } else {
                            disarmResourcePath(resourcePath);
                        }
                    });
                }
                // Capture phase so this runs before the component's own
                // (bubble-phase) change listener fires its immediate request.
                root.addEventListener("change", function(event) {
                    if (event.target && event.target.matches('[data-cmp-hook-contentaisearch="toggle"]')) {
                        armResourcePath(resourcePath);
                    }
                }, true);
            })(roots[i]);
        }
    }

    function init() {
        bindClearButtons();
        bindResultsFade();
        bindSearchTrigger();
    }

    if (document.readyState !== "loading") {
        init();
    } else {
        document.addEventListener("DOMContentLoaded", init);
    }
})();
