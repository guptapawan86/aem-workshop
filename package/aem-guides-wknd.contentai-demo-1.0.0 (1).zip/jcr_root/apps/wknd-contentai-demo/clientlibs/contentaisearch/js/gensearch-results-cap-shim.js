/*
 * Interim demo-only shim: the core ContentAISearchResultsServlet (as
 * currently released) merges results from every configured content source
 * but never truncates the merged list to the component's own resultsSize -
 * it passes a hardcoded 0 as the merge limit, so a page with N sources can
 * return up to N x resultsSize items in one response instead of resultsSize.
 *
 * The real fix (passing model.getResultsSize() through) lives in
 * ContentAISearchResultsServlet.java on the docs/contentai-api-key-config
 * branch of aem-core-wcm-components. Deploying that requires rebuilding and
 * reinstalling the whole core-components bundle, out of scope for this
 * page-level package - so in the meantime, this shim intercepts the
 * component's own .search.json fetches, caches the over-fetched batch
 * client-side, and serves it back resultsSize items at a time so "Load
 * more" keeps working (revealing already-fetched items with no extra
 * network call, then falling back to a real request using the server's own
 * continuation cursors once the local cache is exhausted).
 *
 * Forward-compatible with the real fix: once the server itself starts
 * returning batches already capped to resultsSize, every batch here has
 * nothing left over to reveal locally, so this shim becomes a transparent
 * 1:1 pass-through with no behavior change - see the trace-through in the
 * session notes for why each branch degenerates correctly.
 */
(function() {
    "use strict";

    var SEARCH_JSON_MARKER = ".search.json";
    var CLIENT_CURSOR_KEY = "__client_offset__";
    var sizeCache = {};
    var pageCache = {};
    var originalFetch = window.fetch;

    function getResultsSize(resourcePath) {
        if (Object.prototype.hasOwnProperty.call(sizeCache, resourcePath)) {
            return Promise.resolve(sizeCache[resourcePath]);
        }
        return originalFetch(resourcePath + ".json")
            .then(function(response) {
                return response.ok ? response.json() : {};
            })
            .then(function(data) {
                var size = parseInt(data && data.resultsSize, 10);
                sizeCache[resourcePath] = size > 0 ? size : null;
                return sizeCache[resourcePath];
            })
            .catch(function() {
                sizeCache[resourcePath] = null;
                return null;
            });
    }

    function parseSearchUrl(url) {
        var idx = url.indexOf(SEARCH_JSON_MARKER);
        if (idx === -1) {
            return null;
        }
        var resourcePath = url.substring(0, idx);
        var queryString = url.substring(idx + SEARCH_JSON_MARKER.length).replace(/^\?/, "");
        var params = new URLSearchParams(queryString);
        var query = params.get("q") || "";
        var cursorsRaw = params.get("cursors");
        var cursors = null;
        if (cursorsRaw) {
            try {
                cursors = JSON.parse(cursorsRaw);
            } catch (e) {
                cursors = null;
            }
        }
        return {
            resourcePath: resourcePath,
            query: query,
            cursors: cursors,
            isClientCursor: !!(cursors && Object.prototype.hasOwnProperty.call(cursors, CLIENT_CURSOR_KEY))
        };
    }

    function cacheKey(resourcePath, query) {
        return resourcePath + "::" + query;
    }

    function freshEntry() {
        return {
            allResults: [],
            offset: 0,
            realHasMore: false,
            realSourceCursors: {},
            totalResults: 0
        };
    }

    function getOrCreateEntry(key) {
        if (!pageCache[key]) {
            pageCache[key] = freshEntry();
        }
        return pageCache[key];
    }

    function absorbRealResponse(entry, data) {
        var results = (data && Array.isArray(data.results)) ? data.results : [];
        entry.allResults = entry.allResults.concat(results);
        entry.realHasMore = !!(data && data.hasMore);
        entry.realSourceCursors = (data && data.sourceCursors) || {};
        entry.totalResults = Math.max(entry.totalResults, (data && data.totalResults) || 0, entry.allResults.length);
    }

    function servePage(entry, resultsSize) {
        var slice = entry.allResults.slice(entry.offset, entry.offset + resultsSize);
        entry.offset += slice.length;
        var localRemaining = entry.offset < entry.allResults.length;
        var hasMore = localRemaining || entry.realHasMore;
        var sourceCursors = {};
        if (localRemaining) {
            sourceCursors[CLIENT_CURSOR_KEY] = String(entry.offset);
        } else if (entry.realHasMore) {
            sourceCursors = entry.realSourceCursors;
        }
        return {
            results: slice,
            totalResults: entry.totalResults,
            hasMore: hasMore,
            sourceCursors: sourceCursors
        };
    }

    function syntheticResponse(page) {
        return {
            ok: true,
            status: 200,
            statusText: "OK",
            json: function() {
                return Promise.resolve(page);
            },
            clone: function() {
                return this;
            }
        };
    }

    window.fetch = function(input, init) {
        var url = typeof input === "string" ? input : (input && input.url) || "";
        var parsed = parseSearchUrl(url);

        if (!parsed) {
            return originalFetch.apply(window, arguments);
        }

        var fetchArgs = arguments;
        var key = cacheKey(parsed.resourcePath, parsed.query);

        return getResultsSize(parsed.resourcePath).then(function(resultsSize) {
            if (!resultsSize) {
                return originalFetch.apply(window, fetchArgs);
            }

            var entry = getOrCreateEntry(key);

            if (!parsed.cursors) {
                // A fresh query (no cursors at all) - start this cache entry over
                // rather than continuing from a previous run of the same query.
                entry = freshEntry();
                pageCache[key] = entry;
            }

            if (parsed.isClientCursor && entry.offset < entry.allResults.length) {
                // Enough already-fetched results locally to serve the next page
                // with no network call at all.
                return syntheticResponse(servePage(entry, resultsSize));
            }

            // Need real data: this is either the initial request, a genuine
            // real-cursor request, or our local supply is exhausted and we
            // fall back to the last real continuation cursors we were given.
            var doFetch;
            if (parsed.isClientCursor) {
                var realUrl = parsed.resourcePath + ".search.json?q=" + encodeURIComponent(parsed.query) +
                    "&cursors=" + encodeURIComponent(JSON.stringify(entry.realSourceCursors));
                doFetch = originalFetch(realUrl, init);
            } else {
                doFetch = originalFetch.apply(window, fetchArgs);
            }

            return doFetch.then(function(response) {
                if (!response.ok) {
                    return response;
                }
                return response.json().then(function(data) {
                    absorbRealResponse(entry, data);
                    return syntheticResponse(servePage(entry, resultsSize));
                });
            });
        });
    };
})();
